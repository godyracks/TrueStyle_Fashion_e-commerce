 <!-- 
        - #CTA
      -->

      <section class="section cta" aria-label="cta" style="background-image: url('./assets/images/cta-bg.jpg')">
        <div class="container">

          <p class="cta-subtitle">So What is Next?</p>

          <h2 class="h2 section-title">Are You Ready? Let's get to Work!</h2>

          <a href="#" class="btn btn-secondary">Get Started</a>

        </div>
      </section>