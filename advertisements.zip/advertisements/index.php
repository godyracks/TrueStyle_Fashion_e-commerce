<?php include_once('./ad-templates/header.php'); ?>
<?php include_once('./ad-templates/navbar.php'); ?>
<?php include_once('./ad-templates/_hero.php'); ?>
<?php include_once('./ad-templates/_service.php'); ?>
<?php include_once('./ad-templates/_projects.php'); ?>
<?php include_once('./ad-templates/_call_to_action.php'); ?>
<?php include_once('./ad-templates/_contact.php'); ?>
<?php include_once('./ad-templates/footer.php'); ?>