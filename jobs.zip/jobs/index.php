
<?php
 header('Location:jobs-home'); 
exit();
?>