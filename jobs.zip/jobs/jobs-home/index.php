<!-- Header start -->
<?php include_once('../jobs-templates/job-header.php'); ?>
<!-- Header end -->

<!-- navbar start -->
<?php include_once('../jobs-templates/job-navbar.php'); ?>
<!--  navbar end-->

<!--  -->
<!--  -->
        <!-- Carousel start -->
        <?php include_once('../jobs-templates/job-carousel.php'); ?>
        <!--Carousel end  -->
        <!-- Search Start -->
        <?php include_once('../jobs-templates/job-search.php'); ?>
        <!-- Search End -->


        <!-- Category Start -->
        <?php include_once('../jobs-templates/job-category.php'); ?>
        <!-- Category End -->


        <!-- About Start -->
        <?php include_once('../jobs-templates/job-about.php'); ?>
        <!-- About End -->


        <!-- Jobs Start -->
        <?php include_once('../jobs-templates/jobs.php'); ?>
        <!-- Jobs End -->


        <!-- Testimonial Start -->
        <?php include_once('../jobs-templates/testimonials.php'); ?>
        <!-- Testimonial End -->
        

        <!-- Footer Start -->
        <?php include_once('../jobs-templates/job-footer.php'); ?>
        <!-- Footer End -->


    


	   	 
	   	 
    
	  
