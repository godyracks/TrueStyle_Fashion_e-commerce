<?php 
header('Location:models');
exit();

?>