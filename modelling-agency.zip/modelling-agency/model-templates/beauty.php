<section class="beautyheader">
      <h1 id="beauty">beauty</h1>
    </section>

    <section class="img-gal">
      <img
        src="../portfoliopage/portfoliobeauty.JPG"
        alt="beauty shoot image one"
      />
      <img src="../beauty images/beauty2.jpg" alt="beauty shoot image two" />
      <img src="../beauty images/beauty3.jpeg" alt="beauty shoot image three" />
      <img src="../beauty images/beauty4.jpeg" alt="beauty shoot image four" />
      <img src="../beauty images/beauty6.jpg" alt="beauty shoot image five" />
    </section>