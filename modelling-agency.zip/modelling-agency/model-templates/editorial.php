<section class="editorialheader">
      <h1 id="editorial">editorial</h1>
    </section>

    <section class="img-gal">
      <img
        src="../portfoliopage/portfolioeditorial.jpg"
        alt="editorial shoot image one"
      />
      <img
        src="../editorial images/editorial2.jpg"
        alt="editorial shoot image two"
      />
      <img
        src="../editorial images/editorial3.JPG"
        alt="editorial shoot image three"
      />
      <img
        src="../editorial images/editorial4.JPG"
        alt="editorial shoot image four"
      />
      <img
        src="../editorial images/editorial5.JPG"
        alt="editorial shoot image five"
      />
      <img
        src="../editorial images/editorial6.jpg"
        alt="editorial shoot image six"
      />
      <img
        src="../editorial images/editorial7.jpg"
        alt="editorial shoot image seven"
      />
      <img
        src="../editorial images/editorial8.jpg"
        alt="editorial shoot image eight"
      />
      <img
        src="../editorial images/editorial9.jpg"
        alt="editorial shoot image nine"
      />
      <img
        src="../editorial images/editorial10.JPG"
        alt="editorial shoot image ten"
      />
      <img
        src="../editorial images/editorial11.jpg"
        alt="editorial shoot image eleven"
      />
      <img
        src="../editorial images/editorial12.jpg"
        alt="editorial shoot image twelve"
      />
    </section>