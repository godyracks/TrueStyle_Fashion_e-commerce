<section class="portfolioheader">
      <h1>portfolio</h1>
    </section>
    <section class="portfolio">
      <div class="row">
        <div class="portfoliocol">
          <a class="editorialpage" href="../models/#editorial">
            <img
              src="../portfoliopage/portfolioeditorial.jpg"
              alt="an editorial shoot image of me to represnt my editorial shoot section"
            />
            <div class="layer">
              <h3>editorial</h3>
            </div>
          </a>
        </div>
        <div class="portfoliocol">
          <a class="beautypage" href="../models/#beauty">
            <img
              src="../portfoliopage/portfoliobeauty.JPG"
              alt="a beauty shoot image of me to represnt my beauty shoot section"
            />
            <div class="layer">
              <h3>beauty</h3>
            </div>
          </a>
        </div>
        <div class="portfoliocol">
          <a class="studiopage" href="../models/#studio">
            <img
              src="../portfoliopage/portfoliostudio.JPG"
              alt="a studio shoot image of me to represnt my studio shoot section"
            />
            <div class="layer">
              <h3>studio</h3>
            </div>
          </a>
        </div>
      </div>
    </section>