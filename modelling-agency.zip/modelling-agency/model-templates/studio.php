<section class="studioheader">
      <h1 id="studio">studio</h1>
    </section>

    <section class="img-gal">
      <img
        src="../portfoliopage/portfoliostudio.JPG"
        alt="studio shoot image one"
      />
      <!-- <img src="../aboutpage/aboutimage.JPG" alt="studio shoot image two" /> -->
      <img src="../studio images/studio4.JPG" alt="studio shoot image three" />
      <img src="../studio images/studio7.JPG" alt="studio shoot image four" />
    </section>