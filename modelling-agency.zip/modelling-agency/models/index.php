<?php include_once('../model-templates/header.php') ?>

    <!-- Portfolio -->
    <?php include_once('../model-templates/portfolio.php') ?>
    <?php include_once('../model-templates/editorial.php') ?>
    <?php include_once('../model-templates/beauty.php') ?>
    <?php include_once('../model-templates/studio.php') ?>
    <?php include_once('../model-templates/footer.php') ?>
  


    
   